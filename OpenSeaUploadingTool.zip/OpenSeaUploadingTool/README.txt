# DISCLAIMER / IMPORTANT NOTE BEFORE USE.
<H2>***This application only for personal use. Do NOT resell this application. 
Please inform or twitter me if you see it for sale @klvntss. Thank you !***</H2>


# INSTRUCTIONS
<ul>
  <li>Download and extract this project in your local device (keep all files and folders that come with the repo in this folder)</li>
  
   <li>Put all the NFTs images into a single folder and name them with with a consequetive series of numbers. Example: 1.png, 2.png, 3.png, ...</li>
   <li>Optionally add NFT properties metadata to the .json file in the folder src/json. (etc 1.json)</li>
   <li>Open OpenSeaTool.exe and fill in your beta key. Next, add the variables for your project and upload properties:</li>
     <ul>
       <li>Opensea collection link: https://www.opensea.io/collection/yourcollectionsname/</li>
       <li>Start number 1</li>
       <li>End number 999 or any number</li>
       <li>Default price: 0.005</li>
       <li>Title with end “#” symbol</li>
       <li>Description</li>
       <li>NFT image format "png"</li>
       <li>External link. Start with https://</li>
       <li>Wallet seed phrase</li>
       <li>Metamask password</li>
     </ul>
   <li>Click the "Select first image" button and select the FIRST image in your sequence. (1.png, most likely)</li>
   <li>Check the "Polygon Blockchain" checkbox if you're using the Polygon network.</li>
   <li>Click the "Start" button and wait 5-10 seconds for chrome to open and connect to your OpenSea account.</li>
   <li>Let the sequence run and add your NFTs. This can take several hours depending on the size of your collection.</li>


     
# Checklist before press "start" button
 <p><ul>
   <li>Disabled opensea night mode</li>
   <li>You PC has the latest version of Chrome and its drivers installed</li>
   <li>Opensea collection link must link to a collection you've already created<BR>
     It should look like this : https://www.opensea.io/collection/yourcollectionsname/</li>
   <li>double check your image / json format: 1.png or 1.json</li>
   </ul>
 </p>

If you have any questions or want to get in contact you can find me on twitter by searching @klvntss

# Thanks
<p>Please share and leave your star star</p>
<p>If you found it useful, buy me a coffee( i like coffee :), here is my Ethereum address: <B>0xd5146965809e4286e24dcf2bfbf58c3840d433a2</b></p>
<p>Thank you very much </p>
